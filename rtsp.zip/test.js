const { spawn } = require("child_process");

spawn("ffmeg", ["-r 123"]);
